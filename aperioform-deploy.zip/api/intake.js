// Vercel Serverless Function — POST /api/intake
// Receives the Aperio intake form and notifies the team by email (Resend) and WhatsApp (Cloud API).
// All secrets come from environment variables; nothing here is exposed to the browser.
const env = (k, d = '') => (process.env[k] || d).trim();
const list = (v) => v.split(',').map((s) => s.trim()).filter(Boolean);
const MAIL_TO = list(env('INTAKE_EMAIL_TO', 'Adolsatar@gmail.com,elaffheheyo@icloud.com'));
const WA_TO = list(env('INTAKE_WHATSAPP_TO', '07749494956,+964 771 148 9339'));
const EM = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/, PH = /^\+?\d{9,15}$/;
const hits = new Map();

const clip = (v, n) => String(v ?? '').slice(0, n);
const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const oneLine = (s, n) => clip(s, n * 2).replace(/\s+/g, ' ').trim().slice(0, n);
const waNumber = (n) => { let d = String(n).replace(/\D/g, ''); if (d.startsWith('00')) d = d.slice(2); else if (d.startsWith('0')) d = '964' + d.slice(1); return d; };
const join = (v) => (Array.isArray(v) ? v.join('، ') : v || '');

function limited(ip) {
  const now = Date.now(), arr = (hits.get(ip) || []).filter((t) => now - t < 600000);
  arr.push(now); hits.set(ip, arr); return arr.length > 6; // best-effort on serverless
}

async function sendEmail(to, subject, html, text, replyTo) {
  const r = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: { Authorization: 'Bearer ' + env('RESEND_API_KEY'), 'Content-Type': 'application/json' },
    body: JSON.stringify({ from: env('INTAKE_EMAIL_FROM'), to: [to], subject, html, text, reply_to: replyTo }),
  });
  if (!r.ok) throw new Error('resend ' + r.status + ' ' + clip(await r.text(), 200));
}

async function sendWhatsApp(to, params, fullText) {
  const tpl = env('WHATSAPP_TEMPLATE_NAME');
  const body = tpl
    ? { messaging_product: 'whatsapp', to, type: 'template', template: { name: tpl, language: { code: env('WHATSAPP_TEMPLATE_LANG', 'ar') }, components: [{ type: 'body', parameters: params.map((text) => ({ type: 'text', text })) }] } }
    : { messaging_product: 'whatsapp', to, type: 'text', text: { body: fullText } }; // plain text only delivers inside the 24h window
  const r = await fetch(`https://graph.facebook.com/v21.0/${env('WHATSAPP_PHONE_NUMBER_ID')}/messages`, {
    method: 'POST',
    headers: { Authorization: 'Bearer ' + env('WHATSAPP_TOKEN'), 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!r.ok) throw new Error('whatsapp ' + r.status + ' ' + clip(await r.text(), 300));
}

async function channel(name, ready, targets, fn) {
  const res = { sent: 0, total: targets.length };
  if (!ready) { console.error(`[intake] ${name}: not configured, skipped`); return res; }
  const out = await Promise.allSettled(targets.map((t) => fn(t)));
  out.forEach((o, i) => {
    if (o.status === 'fulfilled') { res.sent++; console.log(`[intake] ${name} -> ${targets[i]}: sent`); }
    else console.error(`[intake] ${name} -> ${targets[i]}: FAILED`, o.reason && o.reason.message);
  });
  return res;
}

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ ok: false, message: 'Method not allowed' });
  const ip = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim() || 'unknown';
  if (limited(ip)) return res.status(429).json({ ok: false, message: 'محاولات كثيرة، حاول مرة ثانية بعد قليل.' });

  let b = req.body;
  if (typeof b === 'string') { try { b = JSON.parse(b); } catch { b = null; } }
  if (!b || typeof b !== 'object') return res.status(400).json({ ok: false, message: 'طلب غير صالح.' });
  if (b.website) return res.status(200).json({ ok: true, channels: {} }); // honeypot (bots)

  const a = b.answers || {};
  const name = clip(a.name, 200).trim(), field = clip(a.field, 200).trim();
  const phone = String(a.phone || '').replace(/[\s\-().]/g, ''), email = clip(a.email, 200).trim();
  if (!name || !field || !PH.test(phone) || !EM.test(email) || a.consent !== true)
    return res.status(400).json({ ok: false, message: 'بعض البيانات الأساسية ناقصة أو غير صحيحة.' });

  const sections = (Array.isArray(b.summary) ? b.summary : []).slice(0, 12).map((s) => ({
    title: clip(s.title, 120),
    items: (Array.isArray(s.items) ? s.items : []).slice(0, 30).map((i) => ({ label: clip(i.label, 160), value: clip(i.value, 4000) })),
  }));

  const subject = oneLine(`طلب موقع جديد — ${name}`, 150);
  const text = [subject, '', ...sections.flatMap((s) => [s.title, ...s.items.map((i) => `${i.label}: ${i.value}`), ''])].join('\n');
  const html = `<div dir="rtl" style="font-family:Tahoma,Arial,sans-serif;background:#F7F5F0;color:#14120F;padding:24px"><h2 style="margin:0 0 4px">${esc(subject)}</h2>` +
    `<p style="margin:0 0 20px;color:#C1592F">${esc(phone)} · ${esc(email)}</p>` +
    sections.map((s) => `<h3 style="border-top:1px solid #ccc;padding-top:14px;margin:18px 0 8px">${esc(s.title)}</h3>` +
      s.items.map((i) => `<p style="margin:6px 0"><b>${esc(i.label)}:</b><br>${esc(i.value).replace(/\n/g, '<br>')}</p>`).join('')).join('') + '</div>';

  const wsum = oneLine(`البريد: ${email} | الأقسام: ${join(a.sections)} | اللغة: ${a.lang || '-'} | التصميم: ${join(a.style)}`, 600);
  const params = [oneLine(name, 100), phone, oneLine(field, 100), oneLine(join(a.goals) || '-', 200), wsum];
  const waText = `طلب موقع جديد 📩\nالاسم: ${name}\nالهاتف: ${phone}\nالنشاط: ${field}\nالهدف: ${join(a.goals) || '-'}\n${wsum}`;

  const [em, wa] = await Promise.all([
    channel('email', env('RESEND_API_KEY') && env('INTAKE_EMAIL_FROM'), MAIL_TO, (t) => sendEmail(t, subject, html, text, email)),
    channel('whatsapp', env('WHATSAPP_TOKEN') && env('WHATSAPP_PHONE_NUMBER_ID'), WA_TO.map(waNumber), (t) => sendWhatsApp(t, params, waText)),
  ]);

  const channels = { email: em, whatsapp: wa };
  if (em.sent + wa.sent === 0) {
    console.error('[intake] NO channel delivered; request lost for:', subject);
    return res.status(502).json({ ok: false, channels, message: 'تعذّر إيصال الطلب لفريق Aperio حالياً. إجاباتك محفوظة بالصفحة، حاول مرة ثانية بعد لحظات.' });
  }
  return res.status(200).json({ ok: true, channels });
};
